"""
DCSE RULES ENGINEERING FILE
File: meta/rule_lifecycle.py

PLACE IN DCSE
------------
Rule set: META-RULE-LIFECYCLE
Scope: Rules about rules
Layer: L1/L2 -> L3
Engineering stage: S2
Status: CANDIDATE / UNSYNCHRONIZED
Version: 0.2.0
Supersedes: v0.1 baseline

PURPOSE
-------
Meta-rules create/revise candidate rules, detect deterioration, and route promotion. They never autonomously rewrite L0.

KNOWLEDGE TRANSFER
------------------
This file is an executable rule module, not prose guidance. Keep atomic rules
small, testable, and composable. Preserve UNKNOWN when evidence is absent.
Generative work may occur inside a bounded transformation, but acceptance,
authority, evidence, and audit remain explicit controls. Do not silently
promote candidate state to operational truth.
"""

from dcse_rules.runtime.models import Rule, Decision

FILE_META={'file_id':'META-RULE-LIFECYCLE-FILE','rule_set_id':'META-RULE-LIFECYCLE','version':'0.2.0','status':'CANDIDATE','scope':'RULES','layer':'L1/L2 -> L3','stage':'S2'}

RULES=[
 Rule('META-001','META-RULE-LIFECYCLE','Repeated validated outcome may create candidate rule','META','0.2.0','CANDIDATE','Convert repeated successful reasoning into deterministic capability.',lambda c: None if c.get('validated_occurrences') is None else c['validated_occurrences']>=c.get('candidate_rule_threshold',3),on_pass=Decision.EXECUTE_AS_CANDIDATE,metadata={'audit_requirement':'independent'}),
 Rule('META-002','META-RULE-LIFECYCLE','Independent validation required for confidence promotion','META','0.2.0','CANDIDATE','Prevent self-confirming learning loops.',lambda c: None if c.get('validator_independence') is None else c['validator_independence'] in {'VERIFIED','REALITY','DCS','SYSTEM_TEST','EXTERNAL_EVIDENCE','MODEL_INDEPENDENT'},on_fail=Decision.REJECT),
 Rule('META-003','META-RULE-LIFECYCLE','Exception rate above tolerance triggers regeneration','META','0.2.0','CANDIDATE','Detect brittle or outdated rules.',lambda c: None if c.get('exception_rate') is None or c.get('max_exception_rate') is None else c['exception_rate']<=c['max_exception_rate'],on_fail=Decision.REGENERATE),
 Rule('META-004','META-RULE-LIFECYCLE','Equivalent rules trigger merge candidate','META','0.2.0','CANDIDATE','Reduce redundant active rules.',lambda c: None if c.get('equivalent') is None else c['equivalent'] is False,on_fail=Decision.EXECUTE_AS_CANDIDATE),
 Rule('META-005','META-RULE-LIFECYCLE','Dormant superseded rule may retire','META','0.2.0','CANDIDATE','Keep active rule base small.',lambda c: None if c.get('superseded') is None else not (c.get('superseded') is True and c.get('active_dependencies',0)==0),on_fail=Decision.EXECUTE_AS_CANDIDATE),
 Rule('META-006','META-RULE-LIFECYCLE','L0 change cannot auto-promote','META','0.2.0','CANDIDATE','End recursive self-amendment at constitutional authority.',lambda c: True if c.get('target_layer')!='L0' else c.get('dcs_authorized') is True,on_fail=Decision.ESCALATE),
 Rule('META-007','META-RULE-LIFECYCLE','Candidate rule requires tests before registration','META','0.2.0','CANDIDATE','No untested rule enters active registry.',lambda c: True if c.get('candidate_rule') is not True else c.get('tests_passed') is True,on_fail=Decision.REJECT),
 Rule('META-008','META-RULE-LIFECYCLE','Rule change preserves predecessor','META','0.2.0','CANDIDATE','Use supersede-over-overwrite for rule history.',lambda c: True if c.get('revising_rule') is not True else c.get('predecessor_preserved') is True,on_fail=Decision.REJECT),
]
COMPOSITES=[]
