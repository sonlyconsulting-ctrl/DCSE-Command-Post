"""
DCSE RULES ENGINEERING FILE
File: runtime/predicates.py

PLACE IN DCSE
------------
Rule set: RUNTIME-PREDICATES
Scope: DCSE-wide
Layer: L3
Engineering stage: S2
Status: CANDIDATE / UNSYNCHRONIZED
Version: 0.2.0
Supersedes: new in v0.2

PURPOSE
-------
Shared deterministic predicates used by all rule sets. Centralization reduces duplicate logic and model dependence.

KNOWLEDGE TRANSFER
------------------
This file is an executable rule module, not prose guidance. Keep atomic rules
small, testable, and composable. Preserve UNKNOWN when evidence is absent.
Generative work may occur inside a bounded transformation, but acceptance,
authority, evidence, and audit remain explicit controls. Do not silently
promote candidate state to operational truth.
"""

from typing import Any, Iterable


def present(ctx, key):
    if key not in ctx or ctx[key] is None:
        return None
    value = ctx[key]
    if isinstance(value, str): return bool(value.strip())
    if isinstance(value, (list, tuple, set, dict)): return bool(value)
    return True


def all_present(ctx, *keys):
    vals=[present(ctx,k) for k in keys]
    if any(v is None for v in vals): return None
    return all(vals)


def true(ctx,key):
    if key not in ctx or ctx[key] is None: return None
    return ctx[key] is True


def false(ctx,key):
    if key not in ctx or ctx[key] is None: return None
    return ctx[key] is False


def one_of(ctx,key,allowed):
    if key not in ctx or ctx[key] is None: return None
    return ctx[key] in set(allowed)


def equals(ctx,key,expected):
    if key not in ctx or ctx[key] is None: return None
    return ctx[key] == expected


def subset(ctx,key,allowed):
    if key not in ctx or ctx[key] is None: return None
    try: return set(ctx[key]).issubset(set(allowed))
    except TypeError: return False


def implies(ctx, antecedent_key, antecedent_value, consequent_key, consequent_value=True):
    if antecedent_key not in ctx or ctx[antecedent_key] is None: return None
    if ctx[antecedent_key] != antecedent_value: return True
    if consequent_key not in ctx or ctx[consequent_key] is None: return None
    return ctx[consequent_key] == consequent_value


def hash_match(ctx, source='source_hash', readback='readback_hash'):
    if source not in ctx or readback not in ctx or ctx[source] is None or ctx[readback] is None: return None
    return ctx[source] == ctx[readback]


def nonnegative(ctx,key):
    if key not in ctx or ctx[key] is None: return None
    try: return float(ctx[key]) >= 0
    except (TypeError,ValueError): return False


def between(ctx,key,lo,hi):
    if key not in ctx or ctx[key] is None: return None
    try: v=float(ctx[key]); return lo <= v <= hi
    except (TypeError,ValueError): return False
