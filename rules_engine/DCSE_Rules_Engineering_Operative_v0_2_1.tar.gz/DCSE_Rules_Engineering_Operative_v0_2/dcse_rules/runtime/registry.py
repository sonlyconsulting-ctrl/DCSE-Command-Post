"""
DCSE RULES ENGINEERING FILE
File: runtime/registry.py

PLACE IN DCSE
------------
Rule set: RUNTIME-REGISTRY
Scope: DCSE-wide
Layer: L3
Engineering stage: S2
Status: CANDIDATE / UNSYNCHRONIZED
Version: 0.2.0
Supersedes: new in v0.2

PURPOSE
-------
Loads and indexes all registered rule sets and detects duplicate rule IDs before runtime.

KNOWLEDGE TRANSFER
------------------
This file is an executable rule module, not prose guidance. Keep atomic rules
small, testable, and composable. Preserve UNKNOWN when evidence is absent.
Generative work may occur inside a bounded transformation, but acceptance,
authority, evidence, and audit remain explicit controls. Do not silently
promote candidate state to operational truth.
"""

from importlib import import_module

MODULES = [
 'dcse_rules.entities.task_rules','dcse_rules.entities.idea_rules','dcse_rules.entities.asset_rules','dcse_rules.entities.ddna_rules','dcse_rules.entities.knowledge_rules',
 'dcse_rules.capabilities.escd_rules','dcse_rules.capabilities.voice_rules','dcse_rules.capabilities.supabase_rules','dcse_rules.capabilities.content_rules',
 'dcse_rules.capabilities.github_rules','dcse_rules.capabilities.deployment_rules','dcse_rules.capabilities.email_rules','dcse_rules.capabilities.file_handling_rules',
 'dcse_rules.capabilities.asset_generation_rules','dcse_rules.capabilities.employment_rules','dcse_rules.capabilities.sc_rules','dcse_rules.capabilities.ss_rules',
 'dcse_rules.capabilities.ti_rules','dcse_rules.capabilities.governance_rules','dcse_rules.capabilities.tribunal_rules','dcse_rules.capabilities.security_rules',
 'dcse_rules.capabilities.communications_rules','dcse_rules.capabilities.media_rules','dcse_rules.meta.rule_lifecycle'
]

def load_registry():
    rules={}; composites={}; files={}
    for name in MODULES:
        mod=import_module(name)
        files[name]=getattr(mod,'FILE_META',{})
        for rule in getattr(mod,'RULES',[]):
            if rule.rule_id in rules: raise ValueError(f'duplicate rule_id: {rule.rule_id}')
            rules[rule.rule_id]=rule
        for comp in getattr(mod,'COMPOSITES',[]):
            if comp.composite_id in composites: raise ValueError(f'duplicate composite_id: {comp.composite_id}')
            composites[comp.composite_id]=comp
    return {'rules':rules,'composites':composites,'files':files}
