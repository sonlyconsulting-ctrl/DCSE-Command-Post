"""
DCSE RULES ENGINEERING FILE
File: runtime/models.py

PLACE IN DCSE
------------
Rule set: RUNTIME-CORE
Scope: DCSE-wide
Layer: L3
Engineering stage: S2
Status: CANDIDATE / UNSYNCHRONIZED
Version: 0.2.0
Supersedes: v0.1 baseline

PURPOSE
-------
Core executable contracts shared by entity, capability, composite, and meta rule sets.

KNOWLEDGE TRANSFER
------------------
This file is an executable rule module, not prose guidance. Keep atomic rules
small, testable, and composable. Preserve UNKNOWN when evidence is absent.
Generative work may occur inside a bounded transformation, but acceptance,
authority, evidence, and audit remain explicit controls. Do not silently
promote candidate state to operational truth.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

class Decision(str, Enum):
    PASS='PASS'; FAIL='FAIL'; UNKNOWN='UNKNOWN'
    EXECUTE='EXECUTE'; EXECUTE_AS_CANDIDATE='EXECUTE_AS_CANDIDATE'
    ESCALATE='ESCALATE'; REGENERATE='REGENERATE'; REJECT='REJECT'

@dataclass(frozen=True)
class Rule:
    rule_id: str
    rule_set_id: str
    name: str
    rule_type: str
    version: str
    status: str
    purpose: str
    predicate: Callable[[Dict[str,Any]], Optional[bool]]
    on_pass: Decision=Decision.PASS
    on_fail: Decision=Decision.FAIL
    on_unknown: Decision=Decision.UNKNOWN
    metadata: Dict[str,Any]=field(default_factory=dict)

@dataclass
class RuleResult:
    rule_id: str
    decision: Decision
    detail: str=''
    evidence: Dict[str,Any]=field(default_factory=dict)

@dataclass(frozen=True)
class CompositeRule:
    composite_id: str
    rule_set_id: str
    name: str
    rule_ids: List[str]
    operator: str='AND'
    status: str='CANDIDATE'
    metadata: Dict[str,Any]=field(default_factory=dict)
