"""
DCSE RULES ENGINEERING FILE
File: runtime/engine.py

PLACE IN DCSE
------------
Rule set: RUNTIME-CORE
Scope: DCSE-wide
Layer: L3
Engineering stage: S2
Status: CANDIDATE / UNSYNCHRONIZED
Version: 0.2.0
Supersedes: v0.1 baseline

PURPOSE
-------
Deterministic L3 executor. Evaluates rules, preserves UNKNOWN, executes composites, and returns auditable atomic results.

KNOWLEDGE TRANSFER
------------------
This file is an executable rule module, not prose guidance. Keep atomic rules
small, testable, and composable. Preserve UNKNOWN when evidence is absent.
Generative work may occur inside a bounded transformation, but acceptance,
authority, evidence, and audit remain explicit controls. Do not silently
promote candidate state to operational truth.
"""

from .models import Rule, RuleResult, CompositeRule, Decision

class RuleEngine:
    def __init__(self, rules=()): self.rules={r.rule_id:r for r in rules}
    def register(self,*rules):
        for r in rules:
            if r.rule_id in self.rules: raise ValueError(f'duplicate rule_id: {r.rule_id}')
            self.rules[r.rule_id]=r
    def evaluate(self,rule_id,context):
        rule=self.rules[rule_id]
        try: verdict=rule.predicate(context)
        except Exception as exc: return RuleResult(rule_id,Decision.UNKNOWN,f'predicate exception: {exc}')
        decision=rule.on_pass if verdict is True else rule.on_fail if verdict is False else rule.on_unknown
        return RuleResult(rule_id,decision,evidence={'rule_set_id':rule.rule_set_id,'version':rule.version})
    def evaluate_composite(self,composite,context):
        results=[self.evaluate(rid,context) for rid in composite.rule_ids]
        # Composite acceptance rules are expected to return PASS/FAIL/UNKNOWN.
        if any(r.decision==Decision.UNKNOWN for r in results): overall=Decision.UNKNOWN
        else:
            passed=[r.decision==Decision.PASS for r in results]
            if composite.operator=='AND': overall=Decision.PASS if all(passed) else Decision.FAIL
            elif composite.operator=='OR': overall=Decision.PASS if any(passed) else Decision.FAIL
            else: raise ValueError(f'unsupported operator: {composite.operator}')
        return {'composite_id':composite.composite_id,'decision':overall.value,'results':[{'rule_id':r.rule_id,'decision':r.decision.value,'detail':r.detail,'evidence':r.evidence} for r in results]}
