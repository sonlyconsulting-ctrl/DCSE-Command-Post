"""
DCSE RULES ENGINEERING FILE
File: entities/knowledge_rules.py

PLACE IN DCSE
------------
Rule set: ENTITY-KNOWLEDGE
Scope: KNOWLEDGE
Layer: L1/L2 -> L3
Engineering stage: S1/S2
Status: CANDIDATE / UNSYNCHRONIZED
Version: 0.2.0
Supersedes: v0.1 baseline

PURPOSE
-------
Rules for enterprise knowledge: assertion, source authority, temporal validity, contradiction, derivation, and supersession.

KNOWLEDGE TRANSFER
------------------
This file is an executable rule module, not prose guidance. Keep atomic rules
small, testable, and composable. Preserve UNKNOWN when evidence is absent.
Generative work may occur inside a bounded transformation, but acceptance,
authority, evidence, and audit remain explicit controls. Do not silently
promote candidate state to operational truth.
"""
from dcse_rules.runtime.models import Rule, CompositeRule
from dcse_rules.runtime.predicates import present
from ._factory import make_base, m

FILE_META={'file_id':'KNW-FILE','rule_set_id':'ENTITY-KNOWLEDGE','version':'0.2.0','status':'CANDIDATE','scope':'KNOWLEDGE','layer':'L1/L2 -> L3','stage':'S1/S2'}
RULES=make_base('KNOWLEDGE','KNW','knowledge_id')
RULES.append(Rule('KNW-005','ENTITY-KNOWLEDGE','Knowledge assertion required','VALIDATION','0.2.0','CANDIDATE','Knowledge object must express a bounded proposition.',lambda c: present(c,'assertion'),metadata=m('entity operation',list(c for c in []))))
RULES.append(Rule('KNW-006','ENTITY-KNOWLEDGE','Knowledge authority class required','CLASSIFICATION','0.2.0','CANDIDATE','Knowledge must record source/authority class.',lambda c: c.get('authority_class') in {'PRIMARY','SECONDARY','DERIVED','DCS_DECISION','SYSTEM_EVIDENCE','UNKNOWN'} if c.get('authority_class') is not None else None,metadata=m('entity operation',list(c for c in []))))
RULES.append(Rule('KNW-007','ENTITY-KNOWLEDGE','Derived knowledge cannot masquerade as source fact','CONTROL','0.2.0','CANDIDATE','Derived interpretation remains labeled until independently validated.',lambda c: True if c.get('authority_class')!='DERIVED' else c.get('representation') in {'DERIVED_INTERPRETATION','CANDIDATE'},metadata=m('entity operation',list(c for c in []))))
RULES.append(Rule('KNW-008','ENTITY-KNOWLEDGE','Knowledge contradiction linked','CONTROL','0.2.0','CANDIDATE','Conflicting assertions must reference the conflict set.',lambda c: True if c.get('contradiction_detected') is not True else bool(c.get('conflicts_with')),metadata=m('entity operation',list(c for c in []))))
RULES.append(Rule('KNW-009','ENTITY-KNOWLEDGE','Time-sensitive knowledge carries temporal scope','VALIDATION','0.2.0','CANDIDATE','Current-state claims that can expire require an effective or observed time.',lambda c: True if c.get('time_sensitive') is not True else bool(c.get('observed_at')) or bool(c.get('effective_at')),metadata=m('entity operation',list(c for c in []))))
RULES.append(Rule('KNW-010','ENTITY-KNOWLEDGE','Knowledge supersession preserves history','CONTROL','0.2.0','CANDIDATE','Updated knowledge supersedes instead of destructive overwrite.',lambda c: True if c.get('supersedes') is None else c.get('overwrite_prior') is not True,metadata=m('entity operation',list(c for c in []))))
COMPOSITES=[
  CompositeRule('KNW-C001','ENTITY-KNOWLEDGE','Knowledge candidate minimum',['KNW-001', 'KNW-002', 'KNW-003', 'KNW-004', 'KNW-005', 'KNW-006'],'AND',metadata={'audit':'L4','status':'CANDIDATE'})
]
