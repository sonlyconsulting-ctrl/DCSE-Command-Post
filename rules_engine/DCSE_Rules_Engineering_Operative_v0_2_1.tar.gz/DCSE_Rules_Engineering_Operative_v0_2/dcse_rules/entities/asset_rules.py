"""
DCSE RULES ENGINEERING FILE
File: entities/asset_rules.py

PLACE IN DCSE
------------
Rule set: ENTITY-ASSET
Scope: ASSET
Layer: L1/L2 -> L3
Engineering stage: S1/S2
Status: CANDIDATE / UNSYNCHRONIZED
Version: 0.2.0
Supersedes: v0.1 baseline

PURPOSE
-------
Rules for source/generated assets: integrity, immutable originals, lineage, location, duplication, and lifecycle.

KNOWLEDGE TRANSFER
------------------
This file is an executable rule module, not prose guidance. Keep atomic rules
small, testable, and composable. Preserve UNKNOWN when evidence is absent.
Generative work may occur inside a bounded transformation, but acceptance,
authority, evidence, and audit remain explicit controls. Do not silently
promote candidate state to operational truth.
"""
from dcse_rules.runtime.models import Rule, CompositeRule
from dcse_rules.runtime.predicates import present
from ._factory import make_base, m

FILE_META={'file_id':'AST-FILE','rule_set_id':'ENTITY-ASSET','version':'0.2.0','status':'CANDIDATE','scope':'ASSET','layer':'L1/L2 -> L3','stage':'S1/S2'}
RULES=make_base('ASSET','AST','asset_id')
RULES.append(Rule('AST-005','ENTITY-ASSET','Asset content hash required','VALIDATION','0.2.0','CANDIDATE','Assets require content identity for integrity and deduplication.',lambda c: present(c,'content_hash'),metadata=m('entity operation',list(c for c in []))))
RULES.append(Rule('AST-006','ENTITY-ASSET','Asset storage location required','VALIDATION','0.2.0','CANDIDATE','Registered assets must resolve to a retrievable location.',lambda c: present(c,'location'),metadata=m('entity operation',list(c for c in []))))
RULES.append(Rule('AST-007','ENTITY-ASSET','Source asset immutable','CONTROL','0.2.0','CANDIDATE','Original source bytes are never overwritten.',lambda c: True if c.get('asset_role')!='SOURCE' else c.get('overwrite_source') is not True,metadata=m('entity operation',list(c for c in []))))
RULES.append(Rule('AST-008','ENTITY-ASSET','Generated asset requires lineage','VALIDATION','0.2.0','CANDIDATE','Generated outputs identify producer inputs and generation run.',lambda c: True if c.get('asset_role')!='GENERATED' else bool(c.get('derived_from')) and bool(c.get('generation_run')),metadata=m('entity operation',list(c for c in []))))
RULES.append(Rule('AST-009','ENTITY-ASSET','Stored asset hash verifies','VALIDATION','0.2.0','CANDIDATE','When readback is performed, stored bytes must match source hash.',lambda c: True if c.get('readback_hash') is None else c.get('readback_hash')==c.get('content_hash'),metadata=m('entity operation',list(c for c in []))))
RULES.append(Rule('AST-010','ENTITY-ASSET','Asset deletion requires governed disposition','CONTROL','0.2.0','CANDIDATE','Deletion cannot erase provenance or bypass retention.',lambda c: True if c.get('delete_requested') is not True else c.get('deletion_authorized') is True and c.get('retention_satisfied') is True,metadata=m('entity operation',list(c for c in []))))
COMPOSITES=[
  CompositeRule('AST-C001','ENTITY-ASSET','Asset registration minimum',['AST-001', 'AST-002', 'AST-003', 'AST-004', 'AST-005', 'AST-006', 'AST-009'],'AND',metadata={'audit':'L4','status':'CANDIDATE'})
]
