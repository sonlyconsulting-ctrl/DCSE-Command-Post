"""
DCSE RULES ENGINEERING FILE
File: entities/task_rules.py

PLACE IN DCSE
------------
Rule set: ENTITY-TASK
Scope: TASK
Layer: L1/L2 -> L3
Engineering stage: S1/S2
Status: CANDIDATE / UNSYNCHRONIZED
Version: 0.2.0
Supersedes: v0.1 baseline

PURPOSE
-------
Rules for actionable work: objective, ownership/authority, dependencies, acceptance, completion evidence, and supersession.

KNOWLEDGE TRANSFER
------------------
This file is an executable rule module, not prose guidance. Keep atomic rules
small, testable, and composable. Preserve UNKNOWN when evidence is absent.
Generative work may occur inside a bounded transformation, but acceptance,
authority, evidence, and audit remain explicit controls. Do not silently
promote candidate state to operational truth.
"""
from dcse_rules.runtime.models import Rule, CompositeRule
from dcse_rules.runtime.predicates import present
from ._factory import make_base, m

FILE_META={'file_id':'TSK-FILE','rule_set_id':'ENTITY-TASK','version':'0.2.0','status':'CANDIDATE','scope':'TASK','layer':'L1/L2 -> L3','stage':'S1/S2'}
RULES=make_base('TASK','TSK','task_id')
RULES.append(Rule('TSK-005','ENTITY-TASK','Task objective required','VALIDATION','0.2.0','CANDIDATE','Every task must state the outcome it is intended to produce.',lambda c: present(c,'objective'),metadata=m('entity operation',list(c for c in []))))
RULES.append(Rule('TSK-006','ENTITY-TASK','Task acceptance criteria required','VALIDATION','0.2.0','CANDIDATE','Completion must be testable rather than narrative.',lambda c: present(c,'acceptance_criteria'),metadata=m('entity operation',list(c for c in []))))
RULES.append(Rule('TSK-007','ENTITY-TASK','Task authority or owner required','CONTROL','0.2.0','CANDIDATE','A task must have an accountable authority/owner or explicit system authority.',lambda c: present(c,'authority') or present(c,'owner'),metadata=m('entity operation',list(c for c in []))))
RULES.append(Rule('TSK-008','ENTITY-TASK','Blocked task requires blocker evidence','VALIDATION','0.2.0','CANDIDATE','BLOCKED cannot be asserted without a blocker.',lambda c: True if c.get('state')!='BLOCKED' else bool(c.get('blocker')),metadata=m('entity operation',list(c for c in []))))
RULES.append(Rule('TSK-009','ENTITY-TASK','Completed task requires completion evidence','VALIDATION','0.2.0','CANDIDATE','COMPLETE requires evidence that acceptance criteria were satisfied.',lambda c: True if c.get('state')!='COMPLETE' else bool(c.get('completion_evidence')),metadata=m('entity operation',list(c for c in []))))
RULES.append(Rule('TSK-010','ENTITY-TASK','Superseded task names successor','VALIDATION','0.2.0','CANDIDATE','SUPERSEDED preserves lineage instead of silent overwrite.',lambda c: True if c.get('state')!='SUPERSEDED' else bool(c.get('superseded_by')),metadata=m('entity operation',list(c for c in []))))
COMPOSITES=[
  CompositeRule('TSK-C001','ENTITY-TASK','Task candidate minimum',['TSK-001', 'TSK-002', 'TSK-003', 'TSK-004', 'TSK-005', 'TSK-006'],'AND',metadata={'audit':'L4','status':'CANDIDATE'})
]
