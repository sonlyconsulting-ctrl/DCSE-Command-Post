"""
DCSE RULES ENGINEERING FILE
File: entities/ddna_rules.py

PLACE IN DCSE
------------
Rule set: ENTITY-DDNA
Scope: DDNA
Layer: L1/L2 -> L3
Engineering stage: S1/S2
Status: CANDIDATE / UNSYNCHRONIZED
Version: 0.2.0
Supersedes: v0.1 baseline

PURPOSE
-------
Rules for DDNA records: source-grounded subject assertions, confidence, contradiction handling, candidate/approved separation, and supersession. The acronym expansion is intentionally not inferred here.

KNOWLEDGE TRANSFER
------------------
This file is an executable rule module, not prose guidance. Keep atomic rules
small, testable, and composable. Preserve UNKNOWN when evidence is absent.
Generative work may occur inside a bounded transformation, but acceptance,
authority, evidence, and audit remain explicit controls. Do not silently
promote candidate state to operational truth.
"""
from dcse_rules.runtime.models import Rule, CompositeRule
from dcse_rules.runtime.predicates import present
from ._factory import make_base, m

FILE_META={'file_id':'DDN-FILE','rule_set_id':'ENTITY-DDNA','version':'0.2.0','status':'CANDIDATE','scope':'DDNA','layer':'L1/L2 -> L3','stage':'S1/S2'}
RULES=make_base('DDNA','DDN','ddna_id')
RULES.append(Rule('DDN-005','ENTITY-DDNA','DDNA subject required','VALIDATION','0.2.0','CANDIDATE','A DDNA record must identify what person/entity/subject it concerns.',lambda c: present(c,'subject'),metadata=m('entity operation',list(c for c in []))))
RULES.append(Rule('DDN-006','ENTITY-DDNA','DDNA assertion required','VALIDATION','0.2.0','CANDIDATE','A DDNA record must contain a specific assertion, attribute, preference, or state.',lambda c: present(c,'assertion'),metadata=m('entity operation',list(c for c in []))))
RULES.append(Rule('DDN-007','ENTITY-DDNA','DDNA confidence bounded','VALIDATION','0.2.0','CANDIDATE','Confidence must use governed discrete states rather than invented precision.',lambda c: c.get('confidence') in {'HIGH','MEDIUM','LOW','UNKNOWN'} if c.get('confidence') is not None else None,metadata=m('entity operation',list(c for c in []))))
RULES.append(Rule('DDN-008','ENTITY-DDNA','DDNA contradiction preserved','CONTROL','0.2.0','CANDIDATE','Conflicting evidence remains visible until resolved.',lambda c: True if c.get('contradiction_detected') is not True else bool(c.get('contradiction_refs')),metadata=m('entity operation',list(c for c in []))))
RULES.append(Rule('DDN-009','ENTITY-DDNA','DDNA operational promotion requires authority','CONTROL','0.2.0','CANDIDATE','Candidate DDNA cannot become approved operational state without promotion authority.',lambda c: True if c.get('promotion_requested') is not True else c.get('promotion_authorized') is True,metadata=m('entity operation',list(c for c in []))))
RULES.append(Rule('DDN-010','ENTITY-DDNA','DDNA supersession preserves prior record','CONTROL','0.2.0','CANDIDATE','New DDNA understanding supersedes rather than overwrites prior evidence.',lambda c: True if c.get('supersedes') is None else c.get('overwrite_prior') is not True,metadata=m('entity operation',list(c for c in []))))
COMPOSITES=[
  CompositeRule('DDN-C001','ENTITY-DDNA','DDNA candidate minimum',['DDN-001', 'DDN-002', 'DDN-003', 'DDN-004', 'DDN-005', 'DDN-006', 'DDN-007'],'AND',metadata={'audit':'L4','status':'CANDIDATE'})
]
