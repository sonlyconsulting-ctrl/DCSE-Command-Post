"""
DCSE RULES ENGINEERING FILE
File: entities/_factory.py

PLACE IN DCSE
------------
Rule set: ENTITY-FACTORY
Scope: TASK/IDEA/ASSET/DDNA/KNOWLEDGE
Layer: L1/L2 -> L3
Engineering stage: S1/S2
Status: CANDIDATE / UNSYNCHRONIZED
Version: 0.2.0
Supersedes: v0.1 baseline

PURPOSE
-------
Common entity-rule constructor. Entity-specific modules add domain rules without duplicating base identity/provenance logic.

KNOWLEDGE TRANSFER
------------------
This file is an executable rule module, not prose guidance. Keep atomic rules
small, testable, and composable. Preserve UNKNOWN when evidence is absent.
Generative work may occur inside a bounded transformation, but acceptance,
authority, evidence, and audit remain explicit controls. Do not silently
promote candidate state to operational truth.
"""

from dcse_rules.runtime.models import Rule, CompositeRule
from dcse_rules.runtime.predicates import present, one_of

COMMON_STATES={'CANDIDATE','ACTIVE','BLOCKED','COMPLETE','SUPERSEDED','ARCHIVED','UNKNOWN','UNRESOLVED'}

def m(trigger,inputs,action='VALIDATE',expected='PASS',authority='L0/L1/L2',evidence='context',confidence='DETERMINISTIC',reversibility='REVERSIBLE',failure='UNKNOWN_OR_FAIL',audit='L4'):
    return {'trigger':trigger,'inputs':inputs,'action':action,'expected_output':expected,'authority_boundary':authority,'evidence_required':evidence,'confidence_requirement':confidence,'reversibility':reversibility,'failure_behavior':failure,'audit_requirement':audit}

def make_base(entity,prefix,id_field):
    rs=f'ENTITY-{entity}'
    rules=[
      Rule(f'{prefix}-001',rs,f'{entity} stable identity','VALIDATION','0.2.0','CANDIDATE','Prevent anonymous operational objects.',lambda c:present(c,id_field),metadata=m('create/update',[id_field])),
      Rule(f'{prefix}-002',rs,f'{entity} provenance required','CONTROL','0.2.0','CANDIDATE','Keep creation and transformation traceable.',lambda c:present(c,'provenance'),metadata=m('create/update',['provenance'],evidence='source/provenance reference')),
      Rule(f'{prefix}-003',rs,f'{entity} preserves uncertainty','CONTROL','0.2.0','CANDIDATE','Unknown evidence must not be silently dropped or converted to fact.',lambda c:one_of(c,'classification_state',{'CLASSIFIED','UNKNOWN','UNRESOLVED'}),metadata=m('classify',['classification_state'])),
      Rule(f'{prefix}-004',rs,f'{entity} lifecycle state valid','VALIDATION','0.2.0','CANDIDATE','Restrict state to governed lifecycle vocabulary.',lambda c:one_of(c,'state',COMMON_STATES),metadata=m('state change',['state'])),
    ]
    return rules
