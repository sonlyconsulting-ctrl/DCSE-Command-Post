"""
DCSE RULES ENGINEERING FILE
File: entities/idea_rules.py

PLACE IN DCSE
------------
Rule set: ENTITY-IDEA
Scope: IDEA
Layer: L1/L2 -> L3
Engineering stage: S1/S2
Status: CANDIDATE / UNSYNCHRONIZED
Version: 0.2.0
Supersedes: v0.1 baseline

PURPOSE
-------
Rules for ideas: preserve provenance and novelty while preventing unreviewed ideas from becoming commitments.

KNOWLEDGE TRANSFER
------------------
This file is an executable rule module, not prose guidance. Keep atomic rules
small, testable, and composable. Preserve UNKNOWN when evidence is absent.
Generative work may occur inside a bounded transformation, but acceptance,
authority, evidence, and audit remain explicit controls. Do not silently
promote candidate state to operational truth.
"""
from dcse_rules.runtime.models import Rule, CompositeRule
from dcse_rules.runtime.predicates import present
from ._factory import make_base, m

FILE_META={'file_id':'IDE-FILE','rule_set_id':'ENTITY-IDEA','version':'0.2.0','status':'CANDIDATE','scope':'IDEA','layer':'L1/L2 -> L3','stage':'S1/S2'}
RULES=make_base('IDEA','IDE','idea_id')
RULES.append(Rule('IDE-005','ENTITY-IDEA','Idea proposition required','VALIDATION','0.2.0','CANDIDATE','An idea must express the proposition, opportunity, or hypothesis.',lambda c: present(c,'proposition'),metadata=m('entity operation',list(c for c in []))))
RULES.append(Rule('IDE-006','ENTITY-IDEA','Idea cannot self-promote to operational commitment','CONTROL','0.2.0','CANDIDATE','Idea state must remain candidate/evaluative until promotion authority exists.',lambda c: True if c.get('state') not in {'ACTIVE','COMPLETE'} else c.get('promotion_authorized') is True,metadata=m('entity operation',list(c for c in []))))
RULES.append(Rule('IDE-007','ENTITY-IDEA','Idea evaluation criteria required before selection','VALIDATION','0.2.0','CANDIDATE','Selection requires stated criteria, not preference alone.',lambda c: True if c.get('selected') is not True else present(c,'evaluation_criteria'),metadata=m('entity operation',list(c for c in []))))
RULES.append(Rule('IDE-008','ENTITY-IDEA','Merged idea preserves source lineage','VALIDATION','0.2.0','CANDIDATE','Merged ideas retain parent/source references.',lambda c: True if c.get('merge') is not True else present(c,'merged_from'),metadata=m('entity operation',list(c for c in []))))
RULES.append(Rule('IDE-009','ENTITY-IDEA','Rejected idea records rationale','VALIDATION','0.2.0','CANDIDATE','Rejection remains explainable and recoverable.',lambda c: True if c.get('disposition')!='REJECTED' else present(c,'rationale'),metadata=m('entity operation',list(c for c in []))))
RULES.append(Rule('IDE-010','ENTITY-IDEA','Idea transformation separates fact from proposal','CONTROL','0.2.0','CANDIDATE','Generated proposal text cannot be stored as verified fact.',lambda c: c.get('representation') in {None,'PROPOSAL','DERIVED_INTERPRETATION','VERIFIED_FACT'} and not (c.get('representation')=='VERIFIED_FACT' and c.get('generated') is True and c.get('independently_validated') is not True),metadata=m('entity operation',list(c for c in []))))
COMPOSITES=[
  CompositeRule('IDE-C001','ENTITY-IDEA','Idea candidate minimum',['IDE-001', 'IDE-002', 'IDE-003', 'IDE-004', 'IDE-005'],'AND',metadata={'audit':'L4','status':'CANDIDATE'})
]
