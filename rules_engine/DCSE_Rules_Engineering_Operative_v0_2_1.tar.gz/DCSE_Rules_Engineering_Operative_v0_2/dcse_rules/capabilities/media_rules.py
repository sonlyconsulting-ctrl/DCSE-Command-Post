"""
DCSE RULES ENGINEERING FILE
File: capabilities/media_rules.py

PLACE IN DCSE
------------
Rule set: CAP-MEDIA
Scope: MEDIA
Layer: L1/L2 -> L3
Engineering stage: S1/S2
Status: CANDIDATE / UNSYNCHRONIZED
Version: 0.2.0
Supersedes: v0.1 baseline

PURPOSE
-------
Media workflow controls: source rights, generation lineage, continuity specification, output integrity, assembly, and publication.

KNOWLEDGE TRANSFER
------------------
This file is an executable rule module, not prose guidance. Keep atomic rules
small, testable, and composable. Preserve UNKNOWN when evidence is absent.
Generative work may occur inside a bounded transformation, but acceptance,
authority, evidence, and audit remain explicit controls. Do not silently
promote candidate state to operational truth.
"""
from dcse_rules.runtime.models import Rule, CompositeRule, Decision

FILE_META={'file_id':'CAP-MEDIA-FILE','rule_set_id':'CAP-MEDIA','version':'0.2.0','status':'CANDIDATE','scope':'MEDIA','layer':'L1/L2 -> L3','stage':'S1/S2'}

RULES=[
  Rule('MED-001','CAP-MEDIA','Media source rights status known','CONTROL','0.2.0','CANDIDATE','Do not use assets whose rights status is unknown',lambda c: c.get('rights_status') in {'OWNED','LICENSED','AUTHORIZED','PUBLIC_DOMAIN','GENERATED','NOT_APPLICABLE'} if c.get('rights_status') is not None else None,on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
  Rule('MED-002','CAP-MEDIA','Generated media records lineage','VALIDATION','0.2.0','CANDIDATE','Preserve prompt/model/input/output provenance',lambda c: True if c.get('generated') is not True else all(c.get(k) for k in ('generation_run','producer','input_refs')),on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('MED-003','CAP-MEDIA','Continuity-controlled production references spec','VALIDATION','0.2.0','CANDIDATE','Character/visual continuity must bind to a reusable specification when required',lambda c: True if c.get('continuity_required') is not True else bool(c.get('continuity_spec_ref')),on_pass=Decision.PASS,on_fail=Decision.REGENERATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'REGENERATE','audit_requirement':'L4'}),
  Rule('MED-004','CAP-MEDIA','Assembled output links components','VALIDATION','0.2.0','CANDIDATE','Final media must trace scenes/audio/voiceover/source assets',lambda c: True if c.get('assembled') is not True else bool(c.get('component_refs')),on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('MED-005','CAP-MEDIA','Publication requires validation and authority','CONTROL','0.2.0','CANDIDATE','Generated/assembled media is not automatically releasable',lambda c: True if c.get('publish') is not True else c.get('validated') is True and c.get('publication_authorized') is True,on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
]
COMPOSITES=[]
