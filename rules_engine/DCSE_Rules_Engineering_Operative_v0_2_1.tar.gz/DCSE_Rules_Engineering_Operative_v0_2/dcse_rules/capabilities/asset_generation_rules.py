"""
DCSE RULES ENGINEERING FILE
File: capabilities/asset_generation_rules.py

PLACE IN DCSE
------------
Rule set: CAP-ASSET-GENERATION
Scope: ASSET-GENERATION
Layer: L1/L2 -> L3
Engineering stage: S1/S2
Status: CANDIDATE / UNSYNCHRONIZED
Version: 0.2.0
Supersedes: v0.1 baseline

PURPOSE
-------
Generated artifact pipeline: objective, inputs, generation run, model/provider, lineage, validation, and registration.

KNOWLEDGE TRANSFER
------------------
This file is an executable rule module, not prose guidance. Keep atomic rules
small, testable, and composable. Preserve UNKNOWN when evidence is absent.
Generative work may occur inside a bounded transformation, but acceptance,
authority, evidence, and audit remain explicit controls. Do not silently
promote candidate state to operational truth.
"""
from dcse_rules.runtime.models import Rule, CompositeRule, Decision

FILE_META={'file_id':'CAP-ASSET-GENERATION-FILE','rule_set_id':'CAP-ASSET-GENERATION','version':'0.2.0','status':'CANDIDATE','scope':'ASSET-GENERATION','layer':'L1/L2 -> L3','stage':'S1/S2'}

RULES=[
  Rule('GEN-001','CAP-ASSET-GENERATION','Generation objective explicit','VALIDATION','0.2.0','CANDIDATE','Avoid unbounded artifact generation',lambda c: bool(c.get('objective')),on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('GEN-002','CAP-ASSET-GENERATION','Generation inputs recorded','VALIDATION','0.2.0','CANDIDATE','Preserve reproducibility and lineage',lambda c: bool(c.get('input_refs')),on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('GEN-003','CAP-ASSET-GENERATION','Producer/run identity recorded','VALIDATION','0.2.0','CANDIDATE','Record model/provider/tool and run identity',lambda c: bool(c.get('producer')) and bool(c.get('generation_run')),on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('GEN-004','CAP-ASSET-GENERATION','Generated output remains candidate until validation','CONTROL','0.2.0','CANDIDATE','Creation is not acceptance',lambda c: True if c.get('validated') is True else c.get('status') in {'CANDIDATE','GENERATED','UNKNOWN'},on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('GEN-005','CAP-ASSET-GENERATION','Accepted generated asset links lineage','VALIDATION','0.2.0','CANDIDATE','Accepted output must trace back to source inputs',lambda c: True if c.get('status')!='ACCEPTED' else bool(c.get('derived_from')),on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
]
COMPOSITES=[]
