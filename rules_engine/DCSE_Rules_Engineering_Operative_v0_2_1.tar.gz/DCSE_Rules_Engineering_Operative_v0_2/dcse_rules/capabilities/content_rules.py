"""
DCSE RULES ENGINEERING FILE
File: capabilities/content_rules.py

PLACE IN DCSE
------------
Rule set: CAP-CONTENT
Scope: CONTENT
Layer: L1/L2 -> L3
Engineering stage: S1/S2
Status: CANDIDATE / UNSYNCHRONIZED
Version: 0.2.0
Supersedes: v0.1 baseline

PURPOSE
-------
Content generation/control: entity identity, audience, voice, factuality, internal/public boundary, claims, and publication.

KNOWLEDGE TRANSFER
------------------
This file is an executable rule module, not prose guidance. Keep atomic rules
small, testable, and composable. Preserve UNKNOWN when evidence is absent.
Generative work may occur inside a bounded transformation, but acceptance,
authority, evidence, and audit remain explicit controls. Do not silently
promote candidate state to operational truth.
"""
from dcse_rules.runtime.models import Rule, CompositeRule, Decision

FILE_META={'file_id':'CAP-CONTENT-FILE','rule_set_id':'CAP-CONTENT','version':'0.2.0','status':'CANDIDATE','scope':'CONTENT','layer':'L1/L2 -> L3','stage':'S1/S2'}

RULES=[
  Rule('CNT-001','CAP-CONTENT','Public content preserves internal/public firewall','CONTROL','0.2.0','CANDIDATE','Prevent internal governance leakage unless explicitly authorized',lambda c: True if c.get('public_content') is not True else c.get('contains_internal_governance') is not True or c.get('explicitly_authorized') is True,on_pass=Decision.PASS,on_fail=Decision.REGENERATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'REGENERATE','audit_requirement':'L4'}),
  Rule('CNT-002','CAP-CONTENT','Factual claims supported','VALIDATION','0.2.0','CANDIDATE','Separate creative generation from factual acceptance',lambda c: True if c.get('has_factual_claims') is not True else c.get('claims_supported') is True,on_pass=Decision.PASS,on_fail=Decision.REGENERATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'REGENERATE','audit_requirement':'L4'}),
  Rule('CNT-003','CAP-CONTENT','Entity identity selected','CLASSIFICATION','0.2.0','CANDIDATE','Use the correct SC/SS/TI/DCSE/public identity before generation',lambda c: c.get('entity_identity') in {'SC','SS','TI','DCSE','DCS_EMPLOYMENT','INTERNAL'} if c.get('entity_identity') is not None else None,on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('CNT-004','CAP-CONTENT','Audience and channel explicit','VALIDATION','0.2.0','CANDIDATE','Prevent generic content detached from audience/channel',lambda c: all(k in c and c[k] for k in ('audience','channel')),on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('CNT-005','CAP-CONTENT','Publication requires release authority','CONTROL','0.2.0','CANDIDATE','Draft freely; publish only within authority',lambda c: True if c.get('publish') is not True else c.get('publication_authorized') is True,on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
]
COMPOSITES=[]
