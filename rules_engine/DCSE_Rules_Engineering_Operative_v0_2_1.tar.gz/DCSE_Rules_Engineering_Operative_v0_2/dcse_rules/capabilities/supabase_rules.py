"""
DCSE RULES ENGINEERING FILE
File: capabilities/supabase_rules.py

PLACE IN DCSE
------------
Rule set: CAP-SUPABASE
Scope: SUPABASE
Layer: L1/L2 -> L3
Engineering stage: S1/S2
Status: CANDIDATE / UNSYNCHRONIZED
Version: 0.2.0
Supersedes: v0.1 baseline

PURPOSE
-------
Supabase data/storage control: connection, writes, readback integrity, schema mutation, secrets, and evidence.

KNOWLEDGE TRANSFER
------------------
This file is an executable rule module, not prose guidance. Keep atomic rules
small, testable, and composable. Preserve UNKNOWN when evidence is absent.
Generative work may occur inside a bounded transformation, but acceptance,
authority, evidence, and audit remain explicit controls. Do not silently
promote candidate state to operational truth.
"""
from dcse_rules.runtime.models import Rule, CompositeRule, Decision

FILE_META={'file_id':'CAP-SUPABASE-FILE','rule_set_id':'CAP-SUPABASE','version':'0.2.0','status':'CANDIDATE','scope':'SUPABASE','layer':'L1/L2 -> L3','stage':'S1/S2'}

RULES=[
  Rule('SUP-001','CAP-SUPABASE','Binary registration requires verified readback','VALIDATION','0.2.0','CANDIDATE','Prevent database records pointing to unverified storage',lambda c: None if any(k not in c for k in ('write_ok','readback_ok','source_hash','readback_hash')) else c['write_ok'] is True and c['readback_ok'] is True and c['source_hash']==c['readback_hash'],on_pass=Decision.PASS,on_fail=Decision.REJECT,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'REJECT','audit_requirement':'L4'}),
  Rule('SUP-002','CAP-SUPABASE','Secrets excluded from ordinary evidence payloads','CONTROL','0.2.0','CANDIDATE','Keep credentials out of logs and records',lambda c: None if c.get('contains_secret') is None else c.get('contains_secret') is False,on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
  Rule('SUP-003','CAP-SUPABASE','Schema mutation requires authority','CONTROL','0.2.0','CANDIDATE','Prevent ungoverned structural changes',lambda c: True if c.get('schema_mutation') is not True else c.get('schema_change_authorized') is True,on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
  Rule('SUP-004','CAP-SUPABASE','Destructive data action requires recovery assurance','CONTROL','0.2.0','CANDIDATE','Require backup/rollback for destructive mutations',lambda c: True if c.get('destructive') is not True else c.get('recovery_assured') is True and c.get('destructive_authorized') is True,on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
  Rule('SUP-005','CAP-SUPABASE','Write result independently verified','VALIDATION','0.2.0','CANDIDATE','Do not claim success from request acceptance alone',lambda c: True if c.get('write_attempted') is not True else c.get('post_write_verified') is True,on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
]
COMPOSITES=[]
