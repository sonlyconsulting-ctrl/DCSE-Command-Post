"""
DCSE RULES ENGINEERING FILE
File: capabilities/security_rules.py

PLACE IN DCSE
------------
Rule set: CAP-SECURITY
Scope: SECURITY
Layer: L1/L2 -> L3
Engineering stage: S1/S2
Status: CANDIDATE / UNSYNCHRONIZED
Version: 0.2.0
Supersedes: v0.1 baseline

PURPOSE
-------
Security capability: secret handling, access scope, protected content, least privilege, logging, and destructive actions.

KNOWLEDGE TRANSFER
------------------
This file is an executable rule module, not prose guidance. Keep atomic rules
small, testable, and composable. Preserve UNKNOWN when evidence is absent.
Generative work may occur inside a bounded transformation, but acceptance,
authority, evidence, and audit remain explicit controls. Do not silently
promote candidate state to operational truth.
"""
from dcse_rules.runtime.models import Rule, CompositeRule, Decision

FILE_META={'file_id':'CAP-SECURITY-FILE','rule_set_id':'CAP-SECURITY','version':'0.2.0','status':'CANDIDATE','scope':'SECURITY','layer':'L1/L2 -> L3','stage':'S1/S2'}

RULES=[
  Rule('SEC-001','CAP-SECURITY','Secrets excluded from normal logs','CONTROL','0.2.0','CANDIDATE','Prevent credential disclosure',lambda c: c.get('secret_in_log') in {None,False},on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
  Rule('SEC-002','CAP-SECURITY','Access scope bounded','CONTROL','0.2.0','CANDIDATE','Use least privilege for operation',lambda c: c.get('requested_scope_within_authority') is True if c.get('access_requested') is True else True,on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
  Rule('SEC-003','CAP-SECURITY','Protected content stays in permitted boundary','CONTROL','0.2.0','CANDIDATE','Enforce confidentiality boundary',lambda c: True if c.get('protected') is not True else c.get('destination_permitted') is True,on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
  Rule('SEC-004','CAP-SECURITY','Destructive security change requires recovery and authority','CONTROL','0.2.0','CANDIDATE','Avoid irreversible lockout/data loss',lambda c: True if c.get('destructive') is not True else c.get('authorized') is True and c.get('recovery_assured') is True,on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
  Rule('SEC-005','CAP-SECURITY','Security-sensitive action audited','VALIDATION','0.2.0','CANDIDATE','Retain independent evidence for sensitive change',lambda c: True if c.get('security_sensitive') is not True else bool(c.get('audit_record')),on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
]
COMPOSITES=[]
