"""
DCSE RULES ENGINEERING FILE
File: capabilities/employment_rules.py

PLACE IN DCSE
------------
Rule set: CAP-EMPLOYMENT
Scope: EMPLOYMENT
Layer: L1/L2 -> L3
Engineering stage: S1/S2
Status: CANDIDATE / UNSYNCHRONIZED
Version: 0.2.0
Supersedes: v0.1 baseline

PURPOSE
-------
DCS Employment opportunity workflow: source, fit, truthfulness, resume tailoring, submission authority, and evidence.

KNOWLEDGE TRANSFER
------------------
This file is an executable rule module, not prose guidance. Keep atomic rules
small, testable, and composable. Preserve UNKNOWN when evidence is absent.
Generative work may occur inside a bounded transformation, but acceptance,
authority, evidence, and audit remain explicit controls. Do not silently
promote candidate state to operational truth.
"""
from dcse_rules.runtime.models import Rule, CompositeRule, Decision

FILE_META={'file_id':'CAP-EMPLOYMENT-FILE','rule_set_id':'CAP-EMPLOYMENT','version':'0.2.0','status':'CANDIDATE','scope':'EMPLOYMENT','layer':'L1/L2 -> L3','stage':'S1/S2'}

RULES=[
  Rule('EMP-001','CAP-EMPLOYMENT','Opportunity source preserved','VALIDATION','0.2.0','CANDIDATE','Retain posting/recruiter provenance',lambda c: bool(c.get('opportunity_source')),on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('EMP-002','CAP-EMPLOYMENT','Experience claims grounded','CONTROL','0.2.0','CANDIDATE','Never add unsupported qualifications to resume/submission',lambda c: c.get('unsupported_claims') in {None,False},on_pass=Decision.PASS,on_fail=Decision.REGENERATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'REGENERATE','audit_requirement':'L4'}),
  Rule('EMP-003','CAP-EMPLOYMENT','Tailoring preserves baseline identity','CONTROL','0.2.0','CANDIDATE','Customize fit without altering verified employment history',lambda c: True if c.get('tailored') is not True else c.get('baseline_facts_preserved') is True,on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('EMP-004','CAP-EMPLOYMENT','Submission requires DCS authority','CONTROL','0.2.0','CANDIDATE','External job application/submission acts in DCS name',lambda c: True if c.get('submit') is not True else c.get('submission_authorized') is True,on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
  Rule('EMP-005','CAP-EMPLOYMENT','Submission evidence captured','VALIDATION','0.2.0','CANDIDATE','Record what version was sent where and when',lambda c: True if c.get('submitted') is not True else all(c.get(k) for k in ('submitted_at','destination','artifact_version')),on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
]
COMPOSITES=[]
