"""
DCSE RULES ENGINEERING FILE
File: capabilities/email_rules.py

PLACE IN DCSE
------------
Rule set: CAP-EMAIL
Scope: EMAIL
Layer: L1/L2 -> L3
Engineering stage: S1/S2
Status: CANDIDATE / UNSYNCHRONIZED
Version: 0.2.0
Supersedes: v0.1 baseline

PURPOSE
-------
Email operation: compose, recipient, authority, protected content, attachments, send evidence, and follow-up.

KNOWLEDGE TRANSFER
------------------
This file is an executable rule module, not prose guidance. Keep atomic rules
small, testable, and composable. Preserve UNKNOWN when evidence is absent.
Generative work may occur inside a bounded transformation, but acceptance,
authority, evidence, and audit remain explicit controls. Do not silently
promote candidate state to operational truth.
"""
from dcse_rules.runtime.models import Rule, CompositeRule, Decision

FILE_META={'file_id':'CAP-EMAIL-FILE','rule_set_id':'CAP-EMAIL','version':'0.2.0','status':'CANDIDATE','scope':'EMAIL','layer':'L1/L2 -> L3','stage':'S1/S2'}

RULES=[
  Rule('EML-001','CAP-EMAIL','Draft creation does not imply send authority','CONTROL','0.2.0','CANDIDATE','Keep composition and transmission separate',lambda c: True if c.get('stage')!='SEND' else c.get('send_authorized') is True,on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
  Rule('EML-002','CAP-EMAIL','Recipients resolved before send','VALIDATION','0.2.0','CANDIDATE','Prevent misaddressed messages',lambda c: True if c.get('stage')!='SEND' else bool(c.get('recipients')),on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('EML-003','CAP-EMAIL','Attachment existence verified','VALIDATION','0.2.0','CANDIDATE','Prevent email referencing missing attachments',lambda c: True if not c.get('attachments') else c.get('attachments_verified') is True,on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('EML-004','CAP-EMAIL','Protected content inside recipient authority','CONTROL','0.2.0','CANDIDATE','Enforce disclosure boundary',lambda c: True if c.get('contains_protected_content') is not True else c.get('protected_recipient_authorized') is True,on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
  Rule('EML-005','CAP-EMAIL','Send result recorded','VALIDATION','0.2.0','CANDIDATE','Capture provider message ID/timestamp after successful send',lambda c: True if c.get('stage')!='SENT' else bool(c.get('provider_message_id')) and bool(c.get('sent_at')),on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
]
COMPOSITES=[]
