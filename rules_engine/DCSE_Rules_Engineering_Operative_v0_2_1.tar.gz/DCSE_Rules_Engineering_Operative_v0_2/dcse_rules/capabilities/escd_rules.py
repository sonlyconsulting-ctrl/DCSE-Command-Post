"""
DCSE RULES ENGINEERING FILE
File: capabilities/escd_rules.py

PLACE IN DCSE
------------
Rule set: CAP-ESCD
Scope: ESCD
Layer: L1/L2 -> L3
Engineering stage: S1/S2
Status: CANDIDATE / UNSYNCHRONIZED
Version: 0.2.0
Supersedes: v0.1 baseline

PURPOSE
-------
ESCD senior virtual-assistant operation: judgment, bounded action, fact/intent separation, transformation, and escalation.

KNOWLEDGE TRANSFER
------------------
This file is an executable rule module, not prose guidance. Keep atomic rules
small, testable, and composable. Preserve UNKNOWN when evidence is absent.
Generative work may occur inside a bounded transformation, but acceptance,
authority, evidence, and audit remain explicit controls. Do not silently
promote candidate state to operational truth.
"""
from dcse_rules.runtime.models import Rule, CompositeRule, Decision

FILE_META={'file_id':'CAP-ESCD-FILE','rule_set_id':'CAP-ESCD','version':'0.2.0','status':'CANDIDATE','scope':'ESCD','layer':'L1/L2 -> L3','stage':'S1/S2'}

RULES=[
  Rule('ESCD-001','CAP-ESCD','High-confidence bounded reversible execution','CONTROL','0.2.0','CANDIDATE','Allow routine execution without unnecessary escalation',lambda c: None if any(k not in c for k in ('confidence','authority_valid','reversible','validation_pass')) else c['confidence']=='HIGH' and c['authority_valid'] is True and c['reversible'] is True and c['validation_pass'] is True,on_pass=Decision.EXECUTE,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
  Rule('ESCD-002','CAP-ESCD','Principal intent remains explicit','CONTROL','0.2.0','CANDIDATE','Never infer DCS intent from model interpretation',lambda c: True if c.get('state_type')!='PRINCIPAL_INTENT' else c.get('intent_source') in {'DCS_EXPLICIT','AUTHORIZED_DIRECTIVE'},on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('ESCD-003','CAP-ESCD','Derived interpretation remains labeled','CONTROL','0.2.0','CANDIDATE','Separate interpretation from verified fact',lambda c: True if c.get('generated') is not True else c.get('state_type') in {'DERIVED_INTERPRETATION','CANDIDATE','PROPOSAL'} or c.get('independently_validated') is True,on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('ESCD-004','CAP-ESCD','Material contradiction surfaced','CONTROL','0.2.0','CANDIDATE','Senior assistant must surface material contradictions without waiting to be asked',lambda c: True if c.get('material_contradiction') is not True else c.get('surfaced') is True,on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
  Rule('ESCD-005','CAP-ESCD','Residual ambiguity routes rather than disappears','CONTROL','0.2.0','CANDIDATE','Unresolved material ambiguity must be candidate/unknown/escalated',lambda c: True if c.get('material_ambiguity') is not True else c.get('disposition') in {'UNKNOWN','CANDIDATE','ESCALATE'},on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
]
COMPOSITES=[]
