"""
DCSE RULES ENGINEERING FILE
File: capabilities/sc_rules.py

PLACE IN DCSE
------------
Rule set: CAP-SC
Scope: SC
Layer: L1/L2 -> L3
Engineering stage: S1/S2
Status: CANDIDATE / UNSYNCHRONIZED
Version: 0.2.0
Supersedes: v0.1 baseline

PURPOSE
-------
Sonly Consulting capability controls: brand identity, public/internal separation, customer-facing claims, assets, and publication.

KNOWLEDGE TRANSFER
------------------
This file is an executable rule module, not prose guidance. Keep atomic rules
small, testable, and composable. Preserve UNKNOWN when evidence is absent.
Generative work may occur inside a bounded transformation, but acceptance,
authority, evidence, and audit remain explicit controls. Do not silently
promote candidate state to operational truth.
"""
from dcse_rules.runtime.models import Rule, CompositeRule, Decision

FILE_META={'file_id':'CAP-SC-FILE','rule_set_id':'CAP-SC','version':'0.2.0','status':'CANDIDATE','scope':'SC','layer':'L1/L2 -> L3','stage':'S1/S2'}

RULES=[
  Rule('SC-001','CAP-SC','SC brand identity explicit','CLASSIFICATION','0.2.0','CANDIDATE','Prevent lane/brand drift',lambda c: c.get('brand')=='SC',on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('SC-002','CAP-SC','Canonical public identity avoids internal governance by default','CONTROL','0.2.0','CANDIDATE','Keep DCSE control-plane language internal unless authorized',lambda c: c.get('contains_internal_governance') is not True or c.get('explicitly_authorized') is True,on_pass=Decision.PASS,on_fail=Decision.REGENERATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'REGENERATE','audit_requirement':'L4'}),
  Rule('SC-003','CAP-SC','Customer claim support required','VALIDATION','0.2.0','CANDIDATE','Prevent unsupported commercial claims',lambda c: True if c.get('has_customer_claims') is not True else c.get('claims_supported') is True,on_pass=Decision.PASS,on_fail=Decision.REGENERATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'REGENERATE','audit_requirement':'L4'}),
  Rule('SC-004','CAP-SC','Public release authority required','CONTROL','0.2.0','CANDIDATE','Separate drafting from publishing',lambda c: True if c.get('publish') is not True else c.get('publication_authorized') is True,on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
  Rule('SC-005','CAP-SC','SC artifact provenance retained','VALIDATION','0.2.0','CANDIDATE','Trace public asset to source/version',lambda c: bool(c.get('provenance')),on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
]
COMPOSITES=[]
