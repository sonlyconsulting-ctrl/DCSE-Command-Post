"""
DCSE RULES ENGINEERING FILE
File: capabilities/deployment_rules.py

PLACE IN DCSE
------------
Rule set: CAP-DEPLOYMENT
Scope: DEPLOYMENT
Layer: L1/L2 -> L3
Engineering stage: S1/S2
Status: CANDIDATE / UNSYNCHRONIZED
Version: 0.2.0
Supersedes: v0.1 baseline

PURPOSE
-------
Provider-neutral deployment control: source lineage, build, environment, promotion, runtime verification, and rollback.

KNOWLEDGE TRANSFER
------------------
This file is an executable rule module, not prose guidance. Keep atomic rules
small, testable, and composable. Preserve UNKNOWN when evidence is absent.
Generative work may occur inside a bounded transformation, but acceptance,
authority, evidence, and audit remain explicit controls. Do not silently
promote candidate state to operational truth.
"""
from dcse_rules.runtime.models import Rule, CompositeRule, Decision

FILE_META={'file_id':'CAP-DEPLOYMENT-FILE','rule_set_id':'CAP-DEPLOYMENT','version':'0.2.0','status':'CANDIDATE','scope':'DEPLOYMENT','layer':'L1/L2 -> L3','stage':'S1/S2'}

RULES=[
  Rule('DEP-001','CAP-DEPLOYMENT','Deployment source immutable reference captured','VALIDATION','0.2.0','CANDIDATE','Every deployment maps to an exact source version',lambda c: bool(c.get('source_sha') or c.get('source_digest')),on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('DEP-002','CAP-DEPLOYMENT','Build success independently verified','VALIDATION','0.2.0','CANDIDATE','Do not equate trigger acceptance with successful build',lambda c: True if c.get('build_triggered') is not True else c.get('build_status')=='SUCCESS',on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('DEP-003','CAP-DEPLOYMENT','Production promotion requires authority','CONTROL','0.2.0','CANDIDATE','Production is consequential even if technically reversible',lambda c: True if c.get('environment')!='production' else c.get('promotion_authorized') is True,on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
  Rule('DEP-004','CAP-DEPLOYMENT','Post-promotion runtime verification required','VALIDATION','0.2.0','CANDIDATE','Deployment is not complete until live behavior is checked',lambda c: True if c.get('environment')!='production' else c.get('runtime_verified') is True,on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('DEP-005','CAP-DEPLOYMENT','Rollback path exists for production','CONTROL','0.2.0','CANDIDATE','Production changes require recovery path',lambda c: True if c.get('environment')!='production' else bool(c.get('rollback_ref')),on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
]
COMPOSITES=[]
