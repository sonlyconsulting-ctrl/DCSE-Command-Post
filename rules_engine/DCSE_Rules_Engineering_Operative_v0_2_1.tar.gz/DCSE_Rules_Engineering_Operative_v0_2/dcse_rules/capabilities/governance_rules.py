"""
DCSE RULES ENGINEERING FILE
File: capabilities/governance_rules.py

PLACE IN DCSE
------------
Rule set: CAP-GOVERNANCE
Scope: GOVERNANCE
Layer: L1/L2 -> L3
Engineering stage: S1/S2
Status: CANDIDATE / UNSYNCHRONIZED
Version: 0.2.0
Supersedes: v0.1 baseline

PURPOSE
-------
DCSE governance capability: canonical authority, lifecycle, evidence, promotion, stop-gates, and supersession.

KNOWLEDGE TRANSFER
------------------
This file is an executable rule module, not prose guidance. Keep atomic rules
small, testable, and composable. Preserve UNKNOWN when evidence is absent.
Generative work may occur inside a bounded transformation, but acceptance,
authority, evidence, and audit remain explicit controls. Do not silently
promote candidate state to operational truth.
"""
from dcse_rules.runtime.models import Rule, CompositeRule, Decision

FILE_META={'file_id':'CAP-GOVERNANCE-FILE','rule_set_id':'CAP-GOVERNANCE','version':'0.2.0','status':'CANDIDATE','scope':'GOVERNANCE','layer':'L1/L2 -> L3','stage':'S1/S2'}

RULES=[
  Rule('GOV-001','CAP-GOVERNANCE','Canonical authority identified','VALIDATION','0.2.0','CANDIDATE','Governed work must name governing source/version',lambda c: bool(c.get('authority_ref')),on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('GOV-002','CAP-GOVERNANCE','Lifecycle transition valid','VALIDATION','0.2.0','CANDIDATE','Prevent impossible promotion/state transitions',lambda c: c.get('transition_valid') is True if c.get('transition_requested') is True else True,on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('GOV-003','CAP-GOVERNANCE','Promotion requires evidence bundle','CONTROL','0.2.0','CANDIDATE','No narrative-only promotion',lambda c: True if c.get('promotion_requested') is not True else bool(c.get('evidence_bundle')),on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
  Rule('GOV-004','CAP-GOVERNANCE','Stop-gate blocks execution when active','CONTROL','0.2.0','CANDIDATE','Active hard-stop cannot be reasoned around',lambda c: c.get('active_stop_gate') in {None,False},on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
  Rule('GOV-005','CAP-GOVERNANCE','Supersession preserves predecessor','CONTROL','0.2.0','CANDIDATE','Doctrine/rules are superseded, not silently overwritten',lambda c: True if c.get('supersedes') is None else c.get('predecessor_preserved') is True,on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
]
COMPOSITES=[]
