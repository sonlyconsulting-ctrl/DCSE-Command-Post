"""
DCSE RULES ENGINEERING FILE
File: capabilities/tribunal_rules.py

PLACE IN DCSE
------------
Rule set: CAP-TRIBUNAL
Scope: TRIBUNAL
Layer: L1/L2 -> L3
Engineering stage: S1/S2
Status: CANDIDATE / UNSYNCHRONIZED
Version: 0.2.0
Supersedes: v0.1 baseline

PURPOSE
-------
Tribunal/intake control: evidence receipt, issue classification, authority, disposition, traceability, and closure.

KNOWLEDGE TRANSFER
------------------
This file is an executable rule module, not prose guidance. Keep atomic rules
small, testable, and composable. Preserve UNKNOWN when evidence is absent.
Generative work may occur inside a bounded transformation, but acceptance,
authority, evidence, and audit remain explicit controls. Do not silently
promote candidate state to operational truth.
"""
from dcse_rules.runtime.models import Rule, CompositeRule, Decision

FILE_META={'file_id':'CAP-TRIBUNAL-FILE','rule_set_id':'CAP-TRIBUNAL','version':'0.2.0','status':'CANDIDATE','scope':'TRIBUNAL','layer':'L1/L2 -> L3','stage':'S1/S2'}

RULES=[
  Rule('TRB-001','CAP-TRIBUNAL','Tribunal item provenance required','VALIDATION','0.2.0','CANDIDATE','Every issue/claim entering Tribunal must be traceable',lambda c: bool(c.get('provenance')),on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('TRB-002','CAP-TRIBUNAL','Issue type classified or unknown','CLASSIFICATION','0.2.0','CANDIDATE','Never drop an item because classification is uncertain',lambda c: c.get('issue_class') in {'DEFECT','GAP','CONFLICT','DECISION','REQUEST','UNKNOWN','UNRESOLVED'} if c.get('issue_class') is not None else None,on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('TRB-003','CAP-TRIBUNAL','Disposition authority explicit','CONTROL','0.2.0','CANDIDATE','Tribunal disposition must be within assigned authority',lambda c: True if c.get('disposition') is None else c.get('authority_valid') is True,on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
  Rule('TRB-004','CAP-TRIBUNAL','Closure requires resolution evidence','VALIDATION','0.2.0','CANDIDATE','Closed is an evidenced state',lambda c: True if c.get('state')!='CLOSED' else bool(c.get('resolution_evidence')),on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('TRB-005','CAP-TRIBUNAL','Escalation retains full issue context','CONTROL','0.2.0','CANDIDATE','Escalation cannot strip evidence or history',lambda c: True if c.get('escalate') is not True else c.get('context_preserved') is True,on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
]
COMPOSITES=[]
