"""
DCSE RULES ENGINEERING FILE
File: capabilities/voice_rules.py

PLACE IN DCSE
------------
Rule set: CAP-VOICE
Scope: VOICE
Layer: L1/L2 -> L3
Engineering stage: S1/S2
Status: CANDIDATE / UNSYNCHRONIZED
Version: 0.2.0
Supersedes: v0.1 baseline

PURPOSE
-------
Voice-channel control: speaking identity, recipient/message authority, transmission boundary, protected content, and evidence.

KNOWLEDGE TRANSFER
------------------
This file is an executable rule module, not prose guidance. Keep atomic rules
small, testable, and composable. Preserve UNKNOWN when evidence is absent.
Generative work may occur inside a bounded transformation, but acceptance,
authority, evidence, and audit remain explicit controls. Do not silently
promote candidate state to operational truth.
"""
from dcse_rules.runtime.models import Rule, CompositeRule, Decision

FILE_META={'file_id':'CAP-VOICE-FILE','rule_set_id':'CAP-VOICE','version':'0.2.0','status':'CANDIDATE','scope':'VOICE','layer':'L1/L2 -> L3','stage':'S1/S2'}

RULES=[
  Rule('VOC-001','CAP-VOICE','External transmission requires valid authority','CONTROL','0.2.0','CANDIDATE','Stop unauthorized speaking/sending',lambda c: True if c.get('action')!='EXTERNAL_TRANSMISSION' else c.get('authority_valid') is True,on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
  Rule('VOC-002','CAP-VOICE','Recipient inside authority scope','VALIDATION','0.2.0','CANDIDATE','Keep delegated authority bounded by recipient class',lambda c: True if c.get('action')!='EXTERNAL_TRANSMISSION' else c.get('recipient_allowed') is True,on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
  Rule('VOC-003','CAP-VOICE','Message class inside authority scope','VALIDATION','0.2.0','CANDIDATE','Keep delegated authority bounded by message type',lambda c: True if c.get('action')!='EXTERNAL_TRANSMISSION' else c.get('message_class_allowed') is True,on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
  Rule('VOC-004','CAP-VOICE','Protected content requires explicit allowance','CONTROL','0.2.0','CANDIDATE','Prevent protected information from leaving allowed boundary',lambda c: True if c.get('contains_protected_content') is not True else c.get('protected_content_allowed') is True,on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
  Rule('VOC-005','CAP-VOICE','Transmission evidence recorded','VALIDATION','0.2.0','CANDIDATE','Every external send retains recipient/content/time/authority evidence',lambda c: True if c.get('action')!='EXTERNAL_TRANSMISSION' else all(k in c and c[k] is not None for k in ('recipient','message_digest','sent_at','authority_ref')),on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
]
COMPOSITES=[]
