"""
DCSE RULES ENGINEERING FILE
File: capabilities/ti_rules.py

PLACE IN DCSE
------------
Rule set: CAP-TI
Scope: TI
Layer: L1/L2 -> L3
Engineering stage: S1/S2
Status: CANDIDATE / UNSYNCHRONIZED
Version: 0.2.0
Supersedes: v0.1 baseline

PURPOSE
-------
Training/education capability controls: sanitization, source integrity, instructional transformation, claims, and release.

KNOWLEDGE TRANSFER
------------------
This file is an executable rule module, not prose guidance. Keep atomic rules
small, testable, and composable. Preserve UNKNOWN when evidence is absent.
Generative work may occur inside a bounded transformation, but acceptance,
authority, evidence, and audit remain explicit controls. Do not silently
promote candidate state to operational truth.
"""
from dcse_rules.runtime.models import Rule, CompositeRule, Decision

FILE_META={'file_id':'CAP-TI-FILE','rule_set_id':'CAP-TI','version':'0.2.0','status':'CANDIDATE','scope':'TI','layer':'L1/L2 -> L3','stage':'S1/S2'}

RULES=[
  Rule('TI-001','CAP-TI','Training source provenance retained','VALIDATION','0.2.0','CANDIDATE','Trace generalized instruction back to governed source',lambda c: bool(c.get('provenance')),on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('TI-002','CAP-TI','Protected/internal material sanitized before training use','CONTROL','0.2.0','CANDIDATE','Prevent accidental disclosure through training assets',lambda c: True if c.get('requires_sanitization') is not True else c.get('sanitized') is True,on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
  Rule('TI-003','CAP-TI','Instruction distinguishes doctrine from example','CONTROL','0.2.0','CANDIDATE','Examples must not silently become governing rules',lambda c: c.get('example_promoted_as_rule') is not True,on_pass=Decision.PASS,on_fail=Decision.REGENERATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'REGENERATE','audit_requirement':'L4'}),
  Rule('TI-004','CAP-TI','Educational claims supported','VALIDATION','0.2.0','CANDIDATE','Keep teaching content accurate',lambda c: True if c.get('has_factual_claims') is not True else c.get('claims_supported') is True,on_pass=Decision.PASS,on_fail=Decision.REGENERATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'REGENERATE','audit_requirement':'L4'}),
  Rule('TI-005','CAP-TI','Publication authority required','CONTROL','0.2.0','CANDIDATE','Training distribution remains controlled',lambda c: True if c.get('publish') is not True else c.get('publication_authorized') is True,on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
]
COMPOSITES=[]
