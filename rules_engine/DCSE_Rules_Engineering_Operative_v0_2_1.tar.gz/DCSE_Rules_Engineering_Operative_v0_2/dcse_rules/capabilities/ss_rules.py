"""
DCSE RULES ENGINEERING FILE
File: capabilities/ss_rules.py

PLACE IN DCSE
------------
Rule set: CAP-SS
Scope: SS
Layer: L1/L2 -> L3
Engineering stage: S1/S2
Status: CANDIDATE / UNSYNCHRONIZED
Version: 0.2.0
Supersedes: v0.1 baseline

PURPOSE
-------
Smoove Spots capability controls: distinct brand identity, narrative integrity, public/internal separation, assets, and release.

KNOWLEDGE TRANSFER
------------------
This file is an executable rule module, not prose guidance. Keep atomic rules
small, testable, and composable. Preserve UNKNOWN when evidence is absent.
Generative work may occur inside a bounded transformation, but acceptance,
authority, evidence, and audit remain explicit controls. Do not silently
promote candidate state to operational truth.
"""
from dcse_rules.runtime.models import Rule, CompositeRule, Decision

FILE_META={'file_id':'CAP-SS-FILE','rule_set_id':'CAP-SS','version':'0.2.0','status':'CANDIDATE','scope':'SS','layer':'L1/L2 -> L3','stage':'S1/S2'}

RULES=[
  Rule('SS-001','CAP-SS','SS brand identity explicit','CLASSIFICATION','0.2.0','CANDIDATE','Keep SS distinct from SC and internal DCSE',lambda c: c.get('brand')=='SS',on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('SS-002','CAP-SS','Narrative content distinguishes fact and fiction','CONTROL','0.2.0','CANDIDATE','Prevent storytelling device from becoming factual claim',lambda c: True if c.get('narrative_mode')!='FICTIONALIZED' else c.get('fiction_disclosed') is True or c.get('internal_only') is True,on_pass=Decision.PASS,on_fail=Decision.REGENERATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'REGENERATE','audit_requirement':'L4'}),
  Rule('SS-003','CAP-SS','Internal governance language excluded by default','CONTROL','0.2.0','CANDIDATE','Keep culture-facing work free of internal control-plane language',lambda c: c.get('contains_internal_governance') is not True or c.get('explicitly_authorized') is True,on_pass=Decision.PASS,on_fail=Decision.REGENERATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'REGENERATE','audit_requirement':'L4'}),
  Rule('SS-004','CAP-SS','Release authority required','CONTROL','0.2.0','CANDIDATE','Separate creation from publication',lambda c: True if c.get('publish') is not True else c.get('publication_authorized') is True,on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
  Rule('SS-005','CAP-SS','Source/media rights status known','VALIDATION','0.2.0','CANDIDATE','Do not publish media with unknown rights state',lambda c: c.get('rights_status') in {'OWNED','LICENSED','AUTHORIZED','PUBLIC_DOMAIN','NOT_APPLICABLE'} if c.get('rights_status') is not None else None,on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
]
COMPOSITES=[]
