"""
DCSE RULES ENGINEERING FILE
File: capabilities/communications_rules.py

PLACE IN DCSE
------------
Rule set: CAP-COMMUNICATIONS
Scope: COMMUNICATIONS
Layer: L1/L2 -> L3
Engineering stage: S1/S2
Status: CANDIDATE / UNSYNCHRONIZED
Version: 0.2.0
Supersedes: v0.1 baseline

PURPOSE
-------
Cross-channel communication controls: identity, audience, authority, factuality, protected content, and transmission evidence.

KNOWLEDGE TRANSFER
------------------
This file is an executable rule module, not prose guidance. Keep atomic rules
small, testable, and composable. Preserve UNKNOWN when evidence is absent.
Generative work may occur inside a bounded transformation, but acceptance,
authority, evidence, and audit remain explicit controls. Do not silently
promote candidate state to operational truth.
"""
from dcse_rules.runtime.models import Rule, CompositeRule, Decision

FILE_META={'file_id':'CAP-COMMUNICATIONS-FILE','rule_set_id':'CAP-COMMUNICATIONS','version':'0.2.0','status':'CANDIDATE','scope':'COMMUNICATIONS','layer':'L1/L2 -> L3','stage':'S1/S2'}

RULES=[
  Rule('COM-001','CAP-COMMUNICATIONS','Speaker/sender identity explicit','CLASSIFICATION','0.2.0','CANDIDATE','Prevent ambiguous representation',lambda c: c.get('sender_identity') in {'DCS','DCSE','SC','SS','TI','DCS_EMPLOYMENT'} if c.get('sender_identity') is not None else None,on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('COM-002','CAP-COMMUNICATIONS','Audience/recipient resolved','VALIDATION','0.2.0','CANDIDATE','Communication must know who receives it',lambda c: bool(c.get('audience') or c.get('recipient')),on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('COM-003','CAP-COMMUNICATIONS','External transmission authority valid','CONTROL','0.2.0','CANDIDATE','Communication in another entity/person name requires authority',lambda c: True if c.get('external') is not True else c.get('authority_valid') is True,on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
  Rule('COM-004','CAP-COMMUNICATIONS','Factual assertions supported','VALIDATION','0.2.0','CANDIDATE','Communication generation does not waive evidence requirement',lambda c: True if c.get('has_factual_claims') is not True else c.get('claims_supported') is True,on_pass=Decision.PASS,on_fail=Decision.REGENERATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'REGENERATE','audit_requirement':'L4'}),
  Rule('COM-005','CAP-COMMUNICATIONS','Transmission evidence retained','VALIDATION','0.2.0','CANDIDATE','Record channel, recipient, content digest, and time',lambda c: True if c.get('sent') is not True else all(c.get(k) for k in ('channel','content_digest','sent_at')),on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
]
COMPOSITES=[]
