"""
DCSE RULES ENGINEERING FILE
File: capabilities/file_handling_rules.py

PLACE IN DCSE
------------
Rule set: CAP-FILE-HANDLING
Scope: FILE-HANDLING
Layer: L1/L2 -> L3
Engineering stage: S1/S2
Status: CANDIDATE / UNSYNCHRONIZED
Version: 0.2.0
Supersedes: v0.1 baseline

PURPOSE
-------
File intake and lifecycle: immutable source, hash/store/readback, extraction, provenance, supersession, and deletion.

KNOWLEDGE TRANSFER
------------------
This file is an executable rule module, not prose guidance. Keep atomic rules
small, testable, and composable. Preserve UNKNOWN when evidence is absent.
Generative work may occur inside a bounded transformation, but acceptance,
authority, evidence, and audit remain explicit controls. Do not silently
promote candidate state to operational truth.
"""
from dcse_rules.runtime.models import Rule, CompositeRule, Decision

FILE_META={'file_id':'CAP-FILE-HANDLING-FILE','rule_set_id':'CAP-FILE-HANDLING','version':'0.2.0','status':'CANDIDATE','scope':'FILE-HANDLING','layer':'L1/L2 -> L3','stage':'S1/S2'}

RULES=[
  Rule('FIL-001','CAP-FILE-HANDLING','Source hash calculated before registration','VALIDATION','0.2.0','CANDIDATE','Establish immutable content identity',lambda c: bool(c.get('source_hash')),on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('FIL-002','CAP-FILE-HANDLING','Store then readback then hash verify','VALIDATION','0.2.0','CANDIDATE','Never register a source file that cannot be retrieved intact',lambda c: None if any(k not in c for k in ('stored','readback','source_hash','readback_hash')) else c['stored'] is True and c['readback'] is True and c['source_hash']==c['readback_hash'],on_pass=Decision.PASS,on_fail=Decision.REJECT,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'REJECT','audit_requirement':'L4'}),
  Rule('FIL-003','CAP-FILE-HANDLING','Original source immutable','CONTROL','0.2.0','CANDIDATE','Preserve source evidence',lambda c: c.get('overwrite_original') is not True,on_pass=Decision.PASS,on_fail=Decision.REJECT,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'REJECT','audit_requirement':'L4'}),
  Rule('FIL-004','CAP-FILE-HANDLING','Extraction records extractor provenance','VALIDATION','0.2.0','CANDIDATE','Derived text remains reproducible',lambda c: True if c.get('extraction_attempted') is not True else bool(c.get('extractor_id')),on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('FIL-005','CAP-FILE-HANDLING','Reread supersedes rather than overwrites','CONTROL','0.2.0','CANDIDATE','Preserve prior reading history',lambda c: True if c.get('reread') is not True else c.get('supersedes_prior_reading') is True,on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
]
COMPOSITES=[]
