"""
DCSE RULES ENGINEERING FILE
File: capabilities/github_rules.py

PLACE IN DCSE
------------
Rule set: CAP-GITHUB
Scope: GITHUB
Layer: L1/L2 -> L3
Engineering stage: S1/S2
Status: CANDIDATE / UNSYNCHRONIZED
Version: 0.2.0
Supersedes: v0.1 baseline

PURPOSE
-------
GitHub repository control: canonical repo, branch lineage, commits, PRs, destructive actions, and evidence.

KNOWLEDGE TRANSFER
------------------
This file is an executable rule module, not prose guidance. Keep atomic rules
small, testable, and composable. Preserve UNKNOWN when evidence is absent.
Generative work may occur inside a bounded transformation, but acceptance,
authority, evidence, and audit remain explicit controls. Do not silently
promote candidate state to operational truth.
"""
from dcse_rules.runtime.models import Rule, CompositeRule, Decision

FILE_META={'file_id':'CAP-GITHUB-FILE','rule_set_id':'CAP-GITHUB','version':'0.2.0','status':'CANDIDATE','scope':'GITHUB','layer':'L1/L2 -> L3','stage':'S1/S2'}

RULES=[
  Rule('GIT-001','CAP-GITHUB','Canonical repository explicitly identified','VALIDATION','0.2.0','CANDIDATE','Prevent changes against assumed repository',lambda c: bool(c.get('canonical_repo')),on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('GIT-002','CAP-GITHUB','Write targets explicit branch or ref','CONTROL','0.2.0','CANDIDATE','Prevent ambiguous branch mutation',lambda c: True if c.get('write') is not True else bool(c.get('target_ref')),on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
  Rule('GIT-003','CAP-GITHUB','Destructive git action requires explicit authority','CONTROL','0.2.0','CANDIDATE','Protect history and branches',lambda c: True if c.get('destructive') is not True else c.get('destructive_authorized') is True,on_pass=Decision.PASS,on_fail=Decision.ESCALATE,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'ESCALATE','audit_requirement':'L4'}),
  Rule('GIT-004','CAP-GITHUB','Commit evidence captured','VALIDATION','0.2.0','CANDIDATE','Every mutation records source SHA and resulting SHA',lambda c: True if c.get('write') is not True else bool(c.get('source_sha')) and bool(c.get('result_sha')),on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
  Rule('GIT-005','CAP-GITHUB','Promotion lineage contains required baseline','VALIDATION','0.2.0','CANDIDATE','Prevent deploy/promotion that omits required history',lambda c: True if c.get('baseline_required') is not True else c.get('baseline_in_lineage') is True,on_pass=Decision.PASS,on_fail=Decision.FAIL,metadata={'trigger':'capability operation','authority_boundary':'L0/L1/L2','evidence_required':'context + L4 audit','confidence_requirement':'deterministic where expressible','reversibility':'operation-specific','failure_behavior':'FAIL','audit_requirement':'L4'}),
]
COMPOSITES=[]
