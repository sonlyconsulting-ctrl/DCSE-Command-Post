# DCSE Rules Engineering v0.2

This package is the second engineering tranche. It deepens all five entity families and adds capability rule sets through Media. It is executable, tested, and designed for exact handoff/clone of the rules-engineering method.

Run tests:

```bash
python -m unittest discover -s tests -v
```

Inspect the rule registry:

```bash
python -c "from dcse_rules.runtime.registry import load_registry; r=load_registry(); print(len(r['rules']), len(r['composites']))"
```

Local passing tests are evidence only; they do not promote the package into canonical DCSE governance.
