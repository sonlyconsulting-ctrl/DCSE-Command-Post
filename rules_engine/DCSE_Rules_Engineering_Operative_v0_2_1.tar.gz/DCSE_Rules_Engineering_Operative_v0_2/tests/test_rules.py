import unittest
from dcse_rules.runtime.engine import RuleEngine
from dcse_rules.entities.task_rules import RULES as TASK_RULES
from dcse_rules.capabilities.supabase_rules import RULES as SUP_RULES
from dcse_rules.runtime.models import Decision
class Smoke(unittest.TestCase):
 def test_unknown_preserved(self):
  self.assertEqual(RuleEngine(TASK_RULES).evaluate('TSK-002',{}).decision,Decision.UNKNOWN)
 def test_hash_mismatch_rejected(self):
  ctx={'write_ok':True,'readback_ok':True,'source_hash':'a','readback_hash':'b'}
  self.assertEqual(RuleEngine(SUP_RULES).evaluate('SUP-001',ctx).decision,Decision.REJECT)
if __name__=='__main__': unittest.main()
