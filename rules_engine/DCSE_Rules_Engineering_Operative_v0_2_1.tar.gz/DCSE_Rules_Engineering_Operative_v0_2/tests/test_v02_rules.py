import unittest
from dcse_rules.runtime.engine import RuleEngine
from dcse_rules.runtime.models import Decision
from dcse_rules.runtime.registry import load_registry
from dcse_rules.entities.task_rules import RULES as TASK_RULES, COMPOSITES as TASK_COMP
from dcse_rules.entities.asset_rules import RULES as ASSET_RULES
from dcse_rules.entities.ddna_rules import RULES as DDNA_RULES
from dcse_rules.capabilities.escd_rules import RULES as ESCD_RULES
from dcse_rules.capabilities.voice_rules import RULES as VOICE_RULES
from dcse_rules.capabilities.deployment_rules import RULES as DEP_RULES
from dcse_rules.capabilities.media_rules import RULES as MEDIA_RULES
from dcse_rules.meta.rule_lifecycle import RULES as META_RULES

class TestV02(unittest.TestCase):
 def test_registry_unique_and_expected_scale(self):
  reg=load_registry(); self.assertGreaterEqual(len(reg['rules']),148); self.assertEqual(len(reg['composites']),5)
 def test_task_composite_pass(self):
  e=RuleEngine(TASK_RULES); ctx={'task_id':'T1','provenance':'src','classification_state':'CLASSIFIED','state':'CANDIDATE','objective':'x','acceptance_criteria':'y'}
  self.assertEqual(e.evaluate_composite(TASK_COMP[0],ctx)['decision'],'PASS')
 def test_task_completion_without_evidence_fails(self):
  e=RuleEngine(TASK_RULES); self.assertEqual(e.evaluate('TSK-009',{'state':'COMPLETE'}).decision,Decision.FAIL)
 def test_source_asset_overwrite_rejected(self):
  e=RuleEngine(ASSET_RULES); self.assertEqual(e.evaluate('AST-007',{'asset_role':'SOURCE','overwrite_source':True}).decision,Decision.FAIL)
 def test_ddna_unknown_confidence_allowed(self):
  e=RuleEngine(DDNA_RULES); self.assertEqual(e.evaluate('DDN-007',{'confidence':'UNKNOWN'}).decision,Decision.PASS)
 def test_escd_high_confidence_execution(self):
  e=RuleEngine(ESCD_RULES); ctx={'confidence':'HIGH','authority_valid':True,'reversible':True,'validation_pass':True}
  self.assertEqual(e.evaluate('ESCD-001',ctx).decision,Decision.EXECUTE)
 def test_voice_send_without_authority_escalates(self):
  e=RuleEngine(VOICE_RULES); self.assertEqual(e.evaluate('VOC-001',{'action':'EXTERNAL_TRANSMISSION','authority_valid':False}).decision,Decision.ESCALATE)
 def test_prod_deploy_needs_authority(self):
  e=RuleEngine(DEP_RULES); self.assertEqual(e.evaluate('DEP-003',{'environment':'production','promotion_authorized':False}).decision,Decision.ESCALATE)
 def test_media_continuity_missing_regenerates(self):
  e=RuleEngine(MEDIA_RULES); self.assertEqual(e.evaluate('MED-003',{'continuity_required':True}).decision,Decision.REGENERATE)
 def test_meta_l0_does_not_auto_rewrite(self):
  e=RuleEngine(META_RULES); self.assertEqual(e.evaluate('META-006',{'target_layer':'L0','dcs_authorized':False}).decision,Decision.ESCALATE)

if __name__=='__main__': unittest.main()
