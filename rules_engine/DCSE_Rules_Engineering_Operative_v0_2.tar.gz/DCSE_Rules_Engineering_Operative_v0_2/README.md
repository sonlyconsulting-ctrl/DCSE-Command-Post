# DCSE Rules Engineering v0.2 — OPERATIVE

This package is the second engineering tranche. It deepens all five entity families and adds capability rule sets through Media. It is executable, tested, and designed for exact handoff/clone of the rules-engineering method.

Run tests:

```bash
python -m unittest discover -s tests -v
```

Inspect the rule registry:

```bash
python -c "from dcse_rules.runtime.registry import load_registry; r=load_registry(); print(len(r['rules']), len(r['composites']))"
```

## Operative status

This rule-engine baseline is **OPERATIVE** under explicit DCS authorization dated 2026-09-13 and is intended for immediate execution/testing. Operative does not mean immutable: L4 evidence can route rules back through S1/S2 for regeneration, supersession, merge, split, or retirement.

Canonical repository: `sonlyconsulting-ctrl/DCSE-Command-Post`  
Canonical path: `rules_engine/`
